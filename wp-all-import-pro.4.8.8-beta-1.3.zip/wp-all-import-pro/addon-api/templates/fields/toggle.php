<label class="pxmi-addon-toggle">
    <input class="pxmi-addon-toggle__input" data-test="input" type="checkbox" placeholder="" value="1" name="<?php echo esc_attr($html_name); ?>" <?php echo $field_value ? 'checked' : ''; ?> />
    <span class="pxmi-addon-toggle__bullet" aria-hidden="true"></span>
</label>
