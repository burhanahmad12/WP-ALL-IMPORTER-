<input type="text" placeholder="" value="<?php echo esc_attr($field_value); ?>" name="<?php echo esc_attr($html_name); ?>" data-test="input" class="text widefat rad4" style="width:200px;" />
